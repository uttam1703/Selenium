package Day_05;
import java.util.*;

public class arraylist {

	public static void main(String[] args) {
		ArrayList<String> a=new ArrayList<String>();
		//a.add("hfjkfh");
		//System.out.println("before:"+a);
		//a.add(56);
		//System.out.println("before:"+a);
		a.add("uttam");
		a.add("balaji");
		a.add("kishor");
		a.add("gujarat");
		// TODO Auto-generated method stub
		System.out.println("before:"+a);
		a.add("chennai");
		System.out.println("after:"+a);
		a.add(2,"cts");
		System.out.println("before:"+a);
		a.remove("balaji");
		System.out.println("before:"+a);
		a.remove(1);
		System.out.println("before:"+a);
		a.add(0,"hi");
		System.out.println("before:"+a);
		for(String s:a)
		{
			System.out.println(s);
		}
		

	}

}
