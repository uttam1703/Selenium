package Day_05;

public class test_int {

	public static void main(String[] args) {
		drawable d=new rectangle();
		d.draw();
		// TODO Auto-generated method stub

	}

}
