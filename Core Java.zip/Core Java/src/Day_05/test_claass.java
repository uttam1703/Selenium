package Day_05;

import java.io.IOException;

public class test_claass {

	public static void main(String[] args) throws IOException {
		getexcell a=new getexcell();
		String file="C:\\cfrbackup-TREGEYWQ\\ex1.xlsx",sheet="Sheet1";
		//int r=10,c=3;
		//String i="chennai";
		double s=0;
		for(int j=0;j<10;j++)
		{
		double  m=a.getexcel(file,sheet,j,0);
		//int i=Integer.parseInt(m);
		s=s+m;
		}
		System.out.println(s);
		
		inputexcell b=new inputexcell();
		b.input(file, sheet, 10, 0, s);
		
		
		// TODO Auto-generated method stub

	}

}
