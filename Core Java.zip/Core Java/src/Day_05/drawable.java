package Day_05;

public interface drawable {
	//public static 
	void draw();
	//{
		//System.out.println("hi");
		
	//}

}
