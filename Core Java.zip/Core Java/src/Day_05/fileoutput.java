package Day_05;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class fileoutput {

	public static void main(String[] args) throws IOException {
		try {
			//FileInputStream fin=new FileInputStream("C:\\cfrbackup-TREGEYWQ\\file1.txt");
			FileOutputStream fout=new FileOutputStream("C:\\cfrbackup-TREGEYWQ\\file2.txt");
			/*int i;
			while((i=fin.read())!=-1)
			{
				System.out.print((char)i);
			}*/
			byte[] d="kem cho".getBytes();
			
			//FileOutputStream fout=new FileOutputStream("C:\\cfrbackup-TREGEYWQ\\file1.txt");
			fout.write(d);
			//fin.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub

	}

}
