package Day_05;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class getexcell {
public double getexcel(String file,String sheet,int r,int c) throws IOException 
{double s = 0;
File f=new File(file);
try {
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet(sheet);
	XSSFRow row=sh.getRow(r);
	XSSFCell cell=row.getCell(c);
	s=cell.getNumericCellValue();
	
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

return s;
	}
}
