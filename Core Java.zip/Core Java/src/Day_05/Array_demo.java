package Day_05;

import java.util.ArrayList;

public class Array_demo {
	ArrayList<student> a=new ArrayList<student>();
	// TODO Auto-generated method stub
	public void create()
	{
		student s1=new student("ramesh",101,56,45);
		student s2=new student("uttam",102,89,41);
		a.add(s1);
		a.add(s2);
	}
	public void display()
	{
		for(student s:a)
		{
			System.out.println("name:"+s.name+" ID:"+s.id+" java:"+s.java+" sel:"+s.selenium+" avg:"+s.av_c());
		}
	}

	public static void main(String[] args) {
		Array_demo k=new Array_demo();
		k.create();
		k.display();
		
		

	}

}
