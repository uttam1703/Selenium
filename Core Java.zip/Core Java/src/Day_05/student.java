package Day_05;

public class student {
	int id;
	String name;
	int selenium;
	int java;
	float avg;
	public student(String name ,int id,int selenium,int java)
	{
		this.java=java;this.selenium=selenium;
		this.id=id;
		this.name=name;
	}
	public float av_c()
	{
		avg=(selenium+java)/2.0f;
		return avg;
	}
	

}
