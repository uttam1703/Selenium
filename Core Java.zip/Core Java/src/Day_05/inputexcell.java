package Day_05;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class inputexcell {
	public void input(String file,String sheet,int r,int c,double i) throws IOException
	{
		File f=new File(file);
		try {
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(sheet);
//			XSSFRow row1=sh.createRow(r);
//			XSSFCell cell1=row1.createCell(c);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.getCell(c);
			
			cell.setCellValue(i);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
//	public static void main(String[] args) throws IOException {
//		String file="C:\\BLS PR\\1.xlsx";
//		String sheet="Sheet1";
//		int r=0,c=0;
//		String i="uttam";
//		inputexcell m=new inputexcell();
//		m.input(file, sheet, r, c, i);
//	}

}
