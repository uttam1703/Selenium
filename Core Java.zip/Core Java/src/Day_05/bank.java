package Day_05;

public abstract class bank {
	abstract float get_roi();
	public void show()
	{
		System.out.println(" bank detail");
	}

}
