package DAY_03;

public class P2 {

	public static void main(String[] args) {
		student uttam=new student();	
		uttam.s=85;
		uttam.j=96;
		uttam.av_c();
		System.out.println("uttam avg:"+uttam.avg);
		student ramesh=new student();	
		ramesh.s=81;
		ramesh.j=75;
        ramesh.av_c();
		System.out.println("ramesh avg:"+ramesh.avg);
		 
		// TODO Auto-generated method stub

	}

}
