package DAY_03;

public class student {
	int id;
	String name;
	int s;
	int j;
	float avg;
	public void av_c()
	{
		avg=(s+j)/2.0f;
	}
	

}
