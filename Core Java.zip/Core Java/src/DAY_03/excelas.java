package DAY_03;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelas {

	public static void main(String[] args) {
		File f=new File("C:\\cfrbackup-TREGEYWQ\\1.xlsx");
		//File f1=new File("C:\\cfrbackup-TREGEYWQ\\2.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			//FileInputStream fis1=new FileInputStream(f1);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			//XSSFWorkbook wb1=new XSSFWorkbook(fis1);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFSheet sh1=wb.getSheet("Sheet2");
			XSSFRow row=sh.getRow(0);
			XSSFRow row1=sh1.getRow(0);
			XSSFCell cell =row.getCell(0);
			XSSFCell cell1 =row1.getCell(0);
			String s=cell.getStringCellValue();
			String s1=cell1.getStringCellValue();
			System.out.println("EXCEL 1:"+s);
			System.out.println("EXCEL 2:"+s1);
			cell1.setCellValue(s);
			FileOutputStream fos =new FileOutputStream(f);
			wb.write(fos);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	

	}

}
