package DAY_03;

public class calc extends libarary {

	public static void main(String[] args) {
		calc c=new calc();
		int d=c.add(6,45);
		System.out.println("addition:"+d);
		// TODO Auto-generated method stub

	}

}
