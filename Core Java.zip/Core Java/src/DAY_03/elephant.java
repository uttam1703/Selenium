package DAY_03;

public class elephant extends animal {
int lr,tu;
public void display_detail()
{
	super.display();
	System.out.println("lotrunk: "+lr+" lotusk: "+tu);
}
}
