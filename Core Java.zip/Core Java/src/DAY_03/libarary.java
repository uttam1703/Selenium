package DAY_03;

public class libarary {
	public int add(int x,int y)
	{
		int z=x+y;
		return z;
	}

}
