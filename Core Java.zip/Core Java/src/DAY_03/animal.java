package DAY_03;

public class animal {
	int height ,weight,age;
	String color;
	char gen;
	public void display()
	{
		System.out.println("height:"+height+" weight:"+weight+" age: "+age+" color: "+color+" gen: "+gen);
		
	}

}
