package DAY_03;
import java.util.*;

public class P1 {

	public static void main(String[] args) {
		System.out.println("enter string:");
		int m=0;
		Scanner n=new Scanner(System.in);
		char c=n.next().charAt(0);
		while(  c!='N') {

			 
			if(c=='a' || c=='A' || c=='e' || c=='E' ||c=='i' || c=='I'||c=='O'||c=='o'||c=='u'||c=='U')
			{	m++;
			
			}
			 c=n.next().charAt(0);
		
			
		
		}
		System.out.println(m);
		
		
		// TODO Auto-generated method stub

	}

}
