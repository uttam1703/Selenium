package DAY_03;

public class basic_calc {
	int num1=62,num2=34;
    public static int add(int x,int y)
    {
        int a=x+y;
        return a;
    }
    public static int sub(int x,int y)
    {
        int b=x-y;
        return b;
    }

}
