package DAY_03;

public class zoo {

	public static void main(String[] args) {
		elephant e1=new elephant();
		e1.height=45;
		e1.age=8;
		e1.weight=200;
		e1.color="blue";
		e1.gen='f';
		e1.lr=47;
		e1.tu=56;
		e1.display_detail();
		
		
		// TODO Auto-generated method stub

	}

}
