package DAY_03;

public class adva_calc extends basic_calc {

	
		public static int mul(int x,int y)
	    {
	        int c=x*y;
	        return c;
	    }
	    public static void main(String args[])
	    {
	        basic_calc a=new basic_calc();
	        a.num1=10;
	        a.num2=5;
	        int m=mul(a.num1,a.num2);
	        int ad=add(a.num1,a.num2);
	        int su=sub(a.num1,a.num2);
	        System.out.println("addition: "+ad+" sub:"+su+" mul:"+m);

	    }
		// TODO Auto-generated method stub

	}


