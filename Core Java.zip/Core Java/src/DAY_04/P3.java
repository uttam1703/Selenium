package DAY_04;
import java.util.*;

public class P3 {
	static String[][] std=  {{"15","satish"},{"03","girish"},{"02","uttam"},{"04","balaji"},{"01","kishore"}};
		static int[][] marks= {{1,85,96},{3,96,45},{2,75,65},{15,56,87},{4,71,39}};
	public static float avg(int ind)
	{
		float avg;
		avg=(marks[ind][1]+marks[ind][2])/2.0f;
		return avg;
	}
	public static int serch(String sid) {
		int index=0;
		int id=Integer.parseInt(sid);
		for(int i=0;i<=4;i++) {
			if(id==P3.marks[i][0])
			{
				index=i;
				break;
			}
		}
		return index;
	}
	public static String getname(String stdid) {
		String n=null;
		for(int j=0;j<=4;j++)
		{
			if(stdid==P3.std[j][0])
			{
				n=P3.std[j][1];
				break;
			}
		}
		return n;

		
	}

	public static void main(String[] args) {
		//String[][] std=  {{"15","satish"},{"03","girish"},{"02","uttam"},{"04","balaji"},{"01","kishore"}};
		//int[][] marks= {{1,85,96},{3,96,45},{2,75,65},{15,56,87},{4,71,39}};
		/*Scanner sc =new Scanner(System.in);
		System.out.println("enter id: ");
		int m=sc.nextInt();*/
		//System.out.println("id| "+"name| "+"avg|");
		
		//int m=P3.serch(std[j][0]);
		
		/*for(int j=0;j<5;j++) {
		for(int i=0;i<5;i++) {
			int n=P3.serch(std[j][0]);
			
				//if(m==n) {
			if(n==marks[i][0]) {
				float k=P3.avg(marks[i][1],marks[i][2]);
				//int s=m-1;
				System.out.println(marks[i][0]+"| "+std[j][1]+" |"+k);
				break;
			//}
			}
			
			
		}}*/
		String nu="15";
		int i=P3.serch(nu);
		int id=Integer.parseInt(nu);
		float a=P3.avg(i);
		String m=P3.getname(nu);
		System.out.println("ID:"+id+" name:"+m+" average:"+a+" indexnumer:"+(i+1));
		
		
		// TODO Auto-generated method stub

	}
	}


