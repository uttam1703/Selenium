package DAY_04;

public class test_bank {
	public static void main(String[] args) {
	bank b;
	b=new icici();
	System.out.println("ICICI:"+b.get_roi());
	b=new hdfc();
	System.out.println("HDFC:"+b.get_roi());
	}

}
