package DAY_04;

public class P2 {

	public static void main(String[] args) {
		student uttam=new student(45,98,06);	
		//uttam.s=85;
		//uttam.j=96;
		uttam.av_c();
		System.out.println("uttam id:"+uttam.id+" avg:"+uttam.avg);
		student ramesh=new student(75,69,01);	
		//ramesh.s=81;
		//ramesh.j=75;
        ramesh.av_c();
		System.out.println("ramesh id:"+ramesh.id+" avg:"+ramesh.avg);
		 
		// TODO Auto-generated method stub

	}

}
