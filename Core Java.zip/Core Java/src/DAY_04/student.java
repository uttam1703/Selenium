package DAY_04;

public class student {
	int id;
	String name;
	int selenium;
	int java;
	float avg;
	public student(int selenium,int java,int id)
	{
		this.java=java;this.selenium=selenium;
		this.id=id;
		//this.name=name;
	}
	public void av_c()
	{
		avg=(selenium+java)/2.0f;
	}
	

}
