package DAY_04;

public class calc_basi {
	public static int add(int x,int y)
	{
		int z=x+y;
		System.out.println("2 p");
		return z;
	}
	public static int add(int x,int y,int m)
	{
		int z=x+y+m;
		System.out.println("3 p");
		return z;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calc_basi c=new calc_basi();
		int m=c.add(6, 8);
		int m1=c.add(3, 4,5);
		System.out.println(m);
		System.out.println(m1);
		

	}

}
