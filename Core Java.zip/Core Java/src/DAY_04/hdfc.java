package DAY_04;

public class hdfc extends bank  {
	public float get_roi()
	{
		return 7.5f;
	}

}
