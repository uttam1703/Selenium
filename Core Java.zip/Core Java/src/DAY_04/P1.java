package DAY_04;
import java.util.*;

public class P1 {

	public static void main(String[] args) {
		String[][] emp= {{"e1","satish"},{"e2","girish"},{"e3","uttam"},{"e4","balaji"},{"e5","kishore"}};
		Scanner s=new Scanner(System.in);
		System.out.println("enter string :");
		String m=s.next();
		for(int i=0;i<5;i++)
			{
			int k=emp[i][0].compareTo(m);
			if(k==0)
			{
				System.out.println("emp name:"+emp[i][1]);
				break;
			}
		}
		// TODO Auto-generated method stub

	}

}
