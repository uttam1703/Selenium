package DAY_02;

public class P6 {

	public static void main(String[] args) {
		String s="i am learning core java rtm gh",s1,s2;
		int v=s.length();
		int i=0,c=0,p2=0,p1=0;
		while(p2!=-1)
		{
			 p2=s.indexOf(" ",i);
			 if(p2>0)
			 {
			s1=s.substring(p1, p2);
			p1=p2;
			i=p2+1;
			System.out.println(s1);
			}
			
			
		}
		s1=s.substring(p1, v);
		System.out.println(s1);
		
		// TODO Auto-generated method stub

	}

}
