package DAY_02;

public class P2 {

	public static void main(String[] args) {
		int[] marks= {85,21,95,56,30,27,61,91};
		float sum=0;
		for(int i=0;i<=7;i=i+2) {
			if(marks[i]%2==1)
			   sum=sum+marks[i];
		}
		System.out.println(sum);
		// TODO Auto-generated method stub

	}

}
