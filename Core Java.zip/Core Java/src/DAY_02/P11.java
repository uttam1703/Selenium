package DAY_02;

public class P11 {

	public static void main(String[] args) {
		int[][] a={{4,5,8,7},{91,56,78,12},{45,21,34,74}};
        int[][] b={{3,2,9,4},{92,54,70,72},{15,24,37,79}};
        int c;
        for(int i=0;i<=2;i++)
        {
            for(int j=0;j<=3;j++)
            {
               c=a[i][j]+b[i][j];
                System.out.print(c+" ");
            }
            System.out.println();
        }
		// TODO Auto-generated method stub

	}

}
