package DAY_02;

public class P9 {

	public static void main(String[] args) {
		int[] a={21,34,91,59,16,44,29,74,49,82};
        int m=a.length;
        int s=0;
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<m;j++)
            {
              s=a[i]+a[j];
              if(s==65)
              {
                  System.out.println("this is sum: "+a[i]+"+"+a[j]+"="+s);
              }
            }
        }
		// TODO Auto-generated method stub

	}

}
