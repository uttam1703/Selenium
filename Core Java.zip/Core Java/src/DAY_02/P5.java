package DAY_02;

public class P5 {

	public static void main(String[] args) {
		String s="i am learning cor java";
		int v=s.length();
		int i=0,c=0,p=0;
		while(p>=0)
		{
			 p=s.indexOf(" ",i);
			c++;
			i=p+1;
			
		}
		System.out.println(c);
		// TODO Auto-generated method stub

	}

}
