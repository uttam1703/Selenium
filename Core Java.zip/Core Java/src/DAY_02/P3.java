package DAY_02;

public class P3 {

	public static void main(String[] args) {
		int[][] m= {{75,82,80},{81,96,95}};
		int r,c,s=0;
		for(r=0;r<=1;r++) {
			for(c=0;c<=2;c++) {
				if(m[r][c]%2==0)
				{
					s=s+m[r][c];
				}
			}
		}
		System.out.println(s);
		// TODO Auto-generated method stub

	}

}
