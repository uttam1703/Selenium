package DAY_02;

public class P10 {

	public static void main(String[] args) {
		String s="Hello, how are you?";
        int l=s.length();
        int m,i=0,c=0;
        while(i!=-1) {
            m = s.indexOf("o", i);
            if(m>0){
            i=m+1;}
            else
            {
                break;
            }
            c++;

        }
        System.out.println(c);
		// TODO Auto-generated method stub

	}

}
