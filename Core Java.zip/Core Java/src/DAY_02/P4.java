package DAY_02;

public class P4 {

	public static void main(String[] args) {
		String s="Chennai",s1="chennai",s2="chennai",s3;
		int l=s.length();
		int v=s.compareTo(s2);
		System.out.println("len "+l+" rt"+v);
		int rv=s.compareToIgnoreCase(s2);
		System.out.println("rc "+rv);
		s3=s.substring(0, 4);
		System.out.println(s3);
		int p=s.indexOf("n",0);
		System.out.println("pos "+p);
		int p1=s.indexOf("n",p+1);
		System.out.println("rerf "+p1);
		
	
		}
		// TODO Auto-generated method stub

	}


