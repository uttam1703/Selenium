package DAY_02;

public class P1 {

	public static void main(String[] args) {
		
		int[] marks= {85,21,95,56,30,27,61,91};
		float sum=0;
		for(int i=0;i<=7;i++) {
			sum=sum+marks[i];
		}
		float avg=(sum/8);
		System.out.println(avg+" "+sum);
		
			if(avg>=70) {
				System.out.println("first class dis");
			}
			else if(avg>=60 && avg<70)
				System.out.println("first class");
			else if(avg>=50 && avg<60)
				System.out.println("second class");
			else
				System.out.println("pass");
				
				
		
		
		// TODO Auto-generated method stub

	}

}
