package DAY_01;

public class P7 {

	public static void main(String[] args) {
		int i,r;
		for(i=0;i<=10;i++) {
			r=i%2;
			if(r==0)
				System.out.println(i);
		}
		// TODO Auto-generated method stub

	}

}
