package DAY_01;

public class P15 {

	public static void main(String[] args) {
		int a=1234589,b=0;
        while(a>0)
        {
            b++;
            a/=10;
        }
        System.out.println(b);

		// TODO Auto-generated method stub

	}

}
