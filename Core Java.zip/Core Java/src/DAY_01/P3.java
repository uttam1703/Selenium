package DAY_01;

public class P3 {

	public static void main(String[] args) {
		int a=20,b=20;
		if(a>b)
		{
			System.out.println(a+" is greter than "+b);
		}
		else if(a==b)
			System.out.println(a+" is equal "+b);
		else
		{
			System.out.println(a+" is not  greter than "+b);
		}
		// TODO Auto-generated method stub

	}

}
