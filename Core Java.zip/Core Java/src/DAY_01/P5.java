package DAY_01;

public class P5 {

	public static void main(String[] args) {
		double s=700000;
		double a,b,c,tax;
		if(s>800000)
		{
			a=((s-800000)*0.3);
			b=((300000)*0.2);
			c=((320000)*0.1);
			tax=a+b+c;
			System.out.println(tax);
		}
		else if(s<=800000 && s>500000) {
			a=((s-500000)*0.2);
			c=((320000)*0.1);
			tax=a+c;
			System.out.println(tax);
		}
		else if(s<=500000 && s>180000) {
			a=((s-180000)*0.1);
			tax=a;
			System.out.println(tax);
		}
		else
		{
			tax=0;
			System.out.println(tax);
		}
		
		
		// TODO Auto-generated method stub

	}

}
