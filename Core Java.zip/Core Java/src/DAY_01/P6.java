package DAY_01;

public class P6 {

	public static void main(String[] args) {
		int i=10;
		switch(i)
		{
		case 10:
			System.out.println("ten");
			break;
		case 20:
			System.out.println("twenty");
		case 30:
			System.out.println("tirty");
			break;
		default:
			System.out.println("no match");
			
		}
		// TODO Auto-generated method stub

	}

}
