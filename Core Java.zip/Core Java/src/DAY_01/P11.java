package DAY_01;

public class P11 {

	public static void main(String[] args) {
		int n=15;
		while(n<75)
		{
			if(n%7==0)
			{
				System.out.print(n+",");
			}
			n++;
		}
		// TODO Auto-generated method stub

	}

}
