package DAY_01;

public class P9 {

	public static void main(String[] args) {
		int i,r,sum=0;
		for(i=1;i<=30;i++)
		{
			if(i%3==0 && i%5!=0 ) {
				System.out.print(i+",");
				sum=sum+i;
			}
		}
		System.out.println();
		System.out.println(sum);
		// TODO Auto-generated method stub

	}

}
