package DAY_01;

public class P8 {

	public static void main(String[] args) {
		int n=1234,s=0,r;
		while(n>0)
		{
			r=n%10;
			s=s+r;
			n/=10;
		}
		System.out.println(s);
		// TODO Auto-generated method stub

	}

}
