package DAY_01;

public class P13 {

	public static void main(String[] args) {
		int n,a=0,b=1,c,i;
		for(i=0;i<10;i++)
		{
		c=a+b;
		a=b;
		b=c;
		System.out.print(a+" ");
		}
		// TODO Auto-generated method stub

	}

}
