package DAY_01;

public class P12 {

	public static void main(String[] args) {
		int i,j,s;
		for(i=5,j=4;i<=9 &&j<=12;i++,j=j+2) {
			s=i*j;
			System.out.println(i+" * "+j+" = "+s);
			
		}
		// TODO Auto-generated method stub

	}

}
