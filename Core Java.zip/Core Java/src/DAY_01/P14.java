package DAY_01;

public class P14 {
	public static void main(String[] args) {
		int n=0,i=1,j,c=0,s=0;
        while(n<10) {
            j = 1;
            c = 0;
            while (j <= i) {
                if (i % j == 0) {
                    c++;
                }
                j++;
            }
            if (c == 2) {
                System.out.print(i+" ");
                n++;
                if(n>5)
                {
                    s=s+i;
                }
            }
            i++;
        }
        System.out.println();
        System.out.println(s);
	}
}
