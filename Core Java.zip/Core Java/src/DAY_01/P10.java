package DAY_01;

public class P10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=59136,r,sum=0;
		while(n>0) {
			r=n%10;
			if(r>=5)
			{
				sum=sum+r;
			}
			n/=10;
		}
		System.out.println(sum);

	}

}
