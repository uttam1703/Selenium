package DAY_01;

public class P16 {

	public static void main(String[] args) {
		int a=236578,r,s=0;
        while(a>0)
        {
            r=a%10;
            s=(s*10)+r;
            a/=10;
        }
        while(s>0)
        {
            r=s%10;
            switch (r){
                case 1:
                    System.out.println(" one");
                    break;
                case 2:
                    System.out.print(" two");
                    break;
                case 3:
                    System.out.print(" three");
                    break;
                case 4:
                    System.out.print(" four");
                    break;
                case 5:
                    System.out.print(" five");
                    break;
                case 6:
                    System.out.print(" six");
                    break;
                case 7:
                    System.out.print(" seven");
                    break;
                case 8:
                    System.out.print(" eight");
                    break;
                case 9:
                    System.out.print(" nine");
                    break;
                default:
                    System.out.print(" zero");
            }
            s/=10;
        }
		// TODO Auto-generated method stub

	}

}
